export {};

declare global {
  const MyBotConfig: KVNamespace
}