import { renameSync } from 'fs';
import { Context, Telegraf, Telegram } from 'telegraf'
import { JsxEmit } from 'typescript'
import secret from '../secrets'
import Command from './Command'
import Event from './function/Event';
// const SensitiveWords = require("js-sensitivewords");
const bot = new Telegraf(secret.botToken)
// const sw = new SensitiveWords();

Event(bot);
bot.use(async (ctx, next) => {
  // sw.addWords(await MyBotConfig.get("SensitiveWord","json"))
//  let str= sw.replaceDfa(ctx.message?.text, "*", false);
//  ctx.reply(str);
  // ctx.reply(JSON.stringify(ctx))
  await Command(ctx,bot);
  
  await next
})

bot.start((ctx) => ctx.reply('Welcome'))
bot.help((ctx) => ctx.reply('Send me a sticker'))
bot.on('sticker', (ctx) => ctx.reply('👍'))
bot.hears('/menu', (ctx) =>{
  ctx.reply(JSON.stringify(ctx))
})
export default bot
