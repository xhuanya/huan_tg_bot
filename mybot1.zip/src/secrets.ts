export default {
  domain: 'my-boot.xh1.workers.dev',
  webhook: 'mybot',
  botToken: '1857257169:AAHD2OSehqDZXvlxcOfZdN-e7B17WNY8nOw',
}
