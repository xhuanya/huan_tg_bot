import bot from './bot'

bot.launch()
